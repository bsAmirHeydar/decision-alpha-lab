[CmdletBinding()]
param(
    [string]$RepoRoot = ".",
    [string]$PatchZip = "decision-alpha-lab-ucee-i10-deep-multiview-pack-v1.1.0.zip",
    [string]$Remote = "origin"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Invoke-Git {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [switch]$AllowFailure
    )

    & git @Arguments
    $exitCode = $LASTEXITCODE
    if (-not $AllowFailure -and $exitCode -ne 0) {
        throw "git $($Arguments -join ' ') failed with exit code $exitCode."
    }
    return $exitCode
}

function Normalize-RepoPath {
    param([Parameter(Mandatory = $true)][string]$Path)
    return ($Path -replace '\\', '/').TrimStart('./')
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoCandidate = Resolve-Path -LiteralPath $RepoRoot
Push-Location $repoCandidate

$tempRoot = $null
$messageFile = $null

try {
    Invoke-Git -Arguments @("rev-parse", "--is-inside-work-tree") | Out-Null
    $repoTop = (& git rev-parse --show-toplevel).Trim()
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($repoTop)) {
        throw "Could not resolve the Git repository root."
    }
    Set-Location -LiteralPath $repoTop

    $branch = (& git branch --show-current).Trim()
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($branch)) {
        throw "The repository is in detached HEAD state. Checkout the target branch first."
    }

    Invoke-Git -Arguments @("remote", "get-url", $Remote) | Out-Null

    if ([System.IO.Path]::IsPathRooted($PatchZip)) {
        $zipPath = $PatchZip
    }
    else {
        $zipPath = Join-Path $scriptDir $PatchZip
    }
    $zipPath = (Resolve-Path -LiteralPath $zipPath).Path

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        $repoFull = [System.IO.Path]::GetFullPath($repoTop).TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
        $archivePaths = New-Object System.Collections.Generic.List[string]

        foreach ($entry in $archive.Entries) {
            if ([string]::IsNullOrWhiteSpace($entry.FullName) -or $entry.FullName.EndsWith('/')) {
                continue
            }

            $relative = Normalize-RepoPath -Path $entry.FullName
            if ([System.IO.Path]::IsPathRooted($relative) -or $relative -match '(^|/)\.\.(/|$)' -or $relative.Contains(':')) {
                throw "Unsafe archive entry detected: $($entry.FullName)"
            }

            $destination = [System.IO.Path]::GetFullPath((Join-Path $repoTop ($relative -replace '/', [System.IO.Path]::DirectorySeparatorChar)))
            if (-not $destination.StartsWith($repoFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Archive entry escapes repository root: $($entry.FullName)"
            }

            $archivePaths.Add($relative)
        }
    }
    finally {
        $archive.Dispose()
    }

    if ($archivePaths.Count -eq 0) {
        throw "The patch archive contains no files."
    }

    # Refuse to overwrite local work only when it overlaps files contained in this patch.
    $patchSet = @{}
    foreach ($path in $archivePaths) { $patchSet[$path] = $true }

    $overlap = New-Object System.Collections.Generic.List[string]
    $statusLines = & git status --porcelain=v1 --untracked-files=all
    if ($LASTEXITCODE -ne 0) { throw "git status failed." }

    foreach ($line in $statusLines) {
        if ([string]::IsNullOrWhiteSpace($line) -or $line.Length -lt 4) { continue }
        $statusPath = $line.Substring(3)
        if ($statusPath.Contains(' -> ')) {
            $statusPath = $statusPath.Split(@(' -> '), [System.StringSplitOptions]::None)[-1]
        }
        $statusPath = Normalize-RepoPath -Path $statusPath.Trim('"')
        if ($patchSet.ContainsKey($statusPath)) { $overlap.Add($statusPath) }
    }

    if ($overlap.Count -gt 0) {
        $details = ($overlap | Sort-Object -Unique) -join "`n  - "
        throw "Local changes overlap patch files. Commit, stash, or restore these files first:`n  - $details"
    }

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("ucee_i10_" + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot | Out-Null
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tempRoot)

    foreach ($relative in $archivePaths) {
        $source = Join-Path $tempRoot ($relative -replace '/', [System.IO.Path]::DirectorySeparatorChar)
        $destination = Join-Path $repoTop ($relative -replace '/', [System.IO.Path]::DirectorySeparatorChar)
        $destinationDir = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $destinationDir)) {
            New-Item -ItemType Directory -Path $destinationDir -Force | Out-Null
        }
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }

    # Requested sequence: expand, remove the patch ZIP, commit, then push.
    Remove-Item -LiteralPath $zipPath -Force

    # Stage only files explicitly listed in the patch archive. Existing unrelated work is untouched.
    $chunkSize = 35
    for ($i = 0; $i -lt $archivePaths.Count; $i += $chunkSize) {
        $last = [Math]::Min($i + $chunkSize - 1, $archivePaths.Count - 1)
        $chunk = @($archivePaths[$i..$last])
        Invoke-Git -Arguments (@("add", "--") + $chunk) | Out-Null
    }

    & git diff --cached --quiet
    $hasStagedChanges = ($LASTEXITCODE -ne 0)

    if ($hasStagedChanges) {
        $commitMessage = @'
feat(ucee): implement I10 deep multi-view graph and regime pack

- add causal sequence contracts, masking, window builders, deterministic temporal references, and optional GRU/Transformer adapter boundaries
- add deterministic OHLCV rasterization, future-suffix pixel audits, fixed visual references, and restricted vision-adapter policy
- add canonical graph topology lineage, deterministic message passing, edge ablations, and optional GNN capability contracts
- add deterministic regime states, transitions, CUSUM change detection, novelty scoring, and expert/global/abstain routing
- add late, confidence-gated, and OOF-only stacked fusion with explicit missing-view semantics
- add transfer leakage boundaries, deterministic distillation, int8 quantization, and export assessment contracts
- enforce non-bypassable deep admission and multi-seed qualification with economics, calibration, ablation, parity, latency, and fallback gates
- register five native Trainer SDK plugins and a frozen 17-algorithm/10-native catalog
- add 24 closed JSON schemas, MQL5 contract mirrors, diagnostics, conformance vectors, and expanded validation tooling
- expand the UCE-I10 Obsidian delivery to 31 detailed notes plus atomic concepts, ADRs, API/schema references, runbooks, and UCE-I11 handoff
- validate 42 phase tests, 231 cumulative UCE tests, and 4/4 engineering-policy checks

MetaEditor compilation remains pending local Windows evidence; no execution or order authority is introduced.
'@
        $messageFile = Join-Path ([System.IO.Path]::GetTempPath()) ("ucee_i10_commit_" + [guid]::NewGuid().ToString('N') + ".txt")
        [System.IO.File]::WriteAllText($messageFile, $commitMessage, (New-Object System.Text.UTF8Encoding($false)))
        Invoke-Git -Arguments @("commit", "-F", $messageFile) | Out-Null
    }
    else {
        Write-Host "No new patch changes were staged; skipping commit."
    }

    Invoke-Git -Arguments @("push", $Remote, $branch) | Out-Null

    $head = (& git rev-parse HEAD).Trim()
    Write-Host ""
    Write-Host "UCE-I10 patch applied successfully."
    Write-Host "Branch : $branch"
    Write-Host "Commit : $head"
    Write-Host "Push   : $Remote/$branch"
    Write-Host "ZIP    : removed"
}
finally {
    if ($messageFile -and (Test-Path -LiteralPath $messageFile)) {
        Remove-Item -LiteralPath $messageFile -Force -ErrorAction SilentlyContinue
    }
    if ($tempRoot -and (Test-Path -LiteralPath $tempRoot)) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    Pop-Location
}
